#ifndef THONGKE_H
#define THONGKE_H

#include "NhanVien.h"
#include <QVector>
#include <QString>

class ThongKe
{
public:
    static QVector<NhanVien*> List_DanhGia(const QVector<NhanVien*>& danhSach, const QString& danhGia);

    static QVector<NhanVien*> List_NgayNghi(const QVector<NhanVien*>& danhSach, int soNgay);
};

#endif // THONGKE_H
