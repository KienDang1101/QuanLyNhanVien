#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "DocFileCSV.h"
#include "GhiFileCSV.h"
#include "Modify.h"
#include "SAPXEP.h"
#include "ThongKe.h"
#include <QFile>
#include <QMessageBox>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent), ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    ui->groupNhapLieu->setVisible(false);

    // Kết nối các nút
    connect(ui->btnDocFile, &QPushButton::clicked, this, &MainWindow::on_btnDocFile_clicked);
    connect(ui->btnXuat, &QPushButton::clicked, this, &MainWindow::on_btnXuatDS_clicked);
    connect(ui->btnThem, &QPushButton::clicked, this, &MainWindow::on_btnThem_clicked);
    connect(ui->btnSua, &QPushButton::clicked, this, &MainWindow::on_btnChinhSua_clicked);
    connect(ui->btnXoa, &QPushButton::clicked, this, &MainWindow::on_btnXoa_clicked);
    connect(ui->btnSapXep, &QPushButton::clicked, this, &MainWindow::on_btnSapXep_clicked);
    connect(ui->btnThongKe, &QPushButton::clicked, this, &MainWindow::on_btnThongKe_clicked);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_btnDocFile_clicked()
{
    QString filePath = "F:/untitled/DanhSach.csv";
    DocFileCSV::DocFile(filePath);
    HienThiCSVLenTableWidget("F:/untitled/DanhSach.csv");
}

void MainWindow::on_btnXuatDS_clicked()
{
    GhiFileCSV::GhiFile("F:/untitled/DanhSach.csv");
    HienThiCSVLenTableWidget("F:/untitled/DanhSach.csv");
}

void MainWindow::on_btnThem_clicked()
{
    ui->groupNhapLieu->setVisible(true);
    ui->groupNhapLieu->setProperty("IDCanSua", 0);
}

void MainWindow::on_btnXoa_clicked()
{
    bool ok;
    int id = QInputDialog::getInt(this, "Xoá nhân viên", "Nhập ID:", 0, 0, 999999, 1, &ok);
    if (ok) {
        Modify::Xoa(id);
    }
    GhiFileCSV::GhiFile("F:/untitled/DanhSach.csv");
    HienThiCSVLenTableWidget("F:/untitled/DanhSach.csv");
}

void MainWindow::on_btnChinhSua_clicked()
{
    bool ok;
    int id = QInputDialog::getInt(this, "Chỉnh sửa nhân viên", "Nhập ID cần sửa:", 0, 0, 999999, 1, &ok);
    if (!ok) return;

    for (NhanVien* nv : DanhSachNhanVien) {
        if (nv->getID() == id) {
            ui->txtID->setText(QString::number(nv->getID()));
            ui->txtHoTen->setText(nv->getHoTen());
            ui->comboChucVu->setCurrentText(nv->getChucVu());
            ui->txtNgayLam->setText(nv->getNgayLam());
            ui->spinNgayLamViec->setValue(nv->getNgayLamViec());
            ui->spinNgayPhep->setValue(nv->getNgayPhepTichLuy());
            ui->spinNghiKP->setValue(nv->getNgayNghiKhongPhep());
            ui->spinLuongCB->setValue(nv->getLuongCoBan());

            // Hiển thị form và nút xác nhận sửa
            ui->groupNhapLieu->setVisible(true);

            // Lưu lại ID gốc cần sửa
            ui->groupNhapLieu->setProperty("IDCanSua", id);
            return;
        }
    }

    QMessageBox::warning(this, "Không tìm thấy", "Không tìm thấy nhân viên với ID đã nhập.");
}

void MainWindow::on_btnSapXep_clicked()
{
    int choose = QInputDialog::getInt(this, "Sắp xếp", "1:ID, 2:Ngày làm việc, 3. Ngày nghỉ tích lũy, 4. Ngày nghỉ không phép, 5. Lương, 6:Danh giá"
                                      , 1, 1, 6, 1);
    int tanggiam = QInputDialog::getInt(this, "Thứ tự", "1: Tăng dần, 2: Giảm dần", 1, 1, 2, 1);
    SAPXEP::SapXepDSNV(DanhSachNhanVien, choose, tanggiam);
    GhiFileCSV::GhiFile("F:/untitled/DanhSach.csv");
    HienThiCSVLenTableWidget("F:/untitled/DanhSach.csv");
}

void MainWindow::on_btnThongKe_clicked()
{
    bool ok;
    int luaChon = QInputDialog::getInt(this,
                                       "Thống kê",
                                       "1. Theo đánh giá\n2. Theo số ngày nghỉ không phép",
                                       1, 1, 2, 1, &ok);

    if (!ok) return;

    if (luaChon == 1)
    {
        int bac = QInputDialog::getInt(this,
                                       "Chọn mức đánh giá",
                                       "1. Tốt\n2. Trung bình\n3. Yếu",
                                       1, 1, 3, 1, &ok);
        if (!ok) return;

        QString danhGia;
        switch (bac)
        {
        case 1:
            danhGia = "Tot";
            break;
        case 2:
            danhGia = "Trung Binh";
            break;
        case 3:
            danhGia = "Yeu";
            break;
        }

        DanhSachNhanVien = ThongKe::List_DanhGia(DanhSachNhanVien, danhGia);
    }
    else if (luaChon == 2)
    {
        int maxNghi = QInputDialog::getInt(this,
                                           "Nhập số ngày nghỉ không phép tối đa",
                                           "Số ngày:", 0, 0, 365, 1, &ok);
        if (!ok) return;

        DanhSachNhanVien = ThongKe::List_NgayNghi(DanhSachNhanVien, maxNghi);
    }
    GhiFileCSV::GhiFile("F:/untitled/Table.csv");
    HienThiCSVLenTableWidget("F:/untitled/Table.csv");
}

void MainWindow::HienThiCSVLenTableWidget(const QString& filePath) {
    QFile file(filePath);
    if (!file.open(QIODevice::ReadOnly | QIODevice::Text)) {
        QMessageBox::warning(this, "Lỗi", "Không thể mở file CSV.");
        return;
    }

    QTextStream in(&file);
    ui->tableWidget->clear();
    ui->tableWidget->setRowCount(0);

    bool firstLine = true;
    int row = 0;

    while (!in.atEnd()) {
        QString line = in.readLine();
        QStringList fields = line.split(',');

        if (firstLine) {
            ui->tableWidget->setColumnCount(fields.size());
            ui->tableWidget->setHorizontalHeaderLabels(fields);
            firstLine = false;
        } else {
            ui->tableWidget->insertRow(row);
            for (int col = 0; col < fields.size(); ++col) {
                ui->tableWidget->setItem(row, col, new QTableWidgetItem(fields[col]));
            }
            row++;
        }
    }

    file.close();
}

void MainWindow::on_pushButton_clicked()
{
    int idGoc = ui->groupNhapLieu->property("IDCanSua").toInt();
    int id;
    QString hoten = ui->txtHoTen->text();
    QString chucvu = ui->comboChucVu->currentText();
    QString ngaylam = ui->txtNgayLam->text();
    int ngaylv = ui->spinNgayLamViec->value();
    int ngayphep = ui->spinNgayPhep->value();
    int nghikp = ui->spinNghiKP->value();
    int luong = ui->spinLuongCB->value();
    if (idGoc == 0) {
        id = ui->txtID->text().toInt();
        Modify::Them(id, ngaylv, ngayphep, nghikp, luong, hoten, ngaylam, chucvu);
    }
    else {
        id = idGoc;
        Modify::ChinhSua(id, ngaylv, ngayphep, nghikp, luong, hoten, ngaylam, chucvu);
    }

    // Cập nhật giao diện
    GhiFileCSV::GhiFile("F:/untitled/DanhSach.csv");
    HienThiCSVLenTableWidget("F:/untitled/DanhSach.csv");

    QMessageBox::information(this, "Cập nhật", "Đã chỉnh sửa danh sách.");
    ui->groupNhapLieu->setVisible(false);
}

