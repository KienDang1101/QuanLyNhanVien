#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QTableWidget>
#include <QInputDialog>

#include "NhanVien.h"

QT_BEGIN_NAMESPACE
namespace Ui {
class MainWindow;
}
QT_END_NAMESPACE

extern QVector<NhanVien*> DanhSachNhanVien;

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    void on_pushButton_clicked();

private:
    Ui::MainWindow *ui;
    bool chinhsua;
    void on_btnDocFile_clicked();
    void on_btnXuatDS_clicked();
    void on_btnChinhSua_clicked();
    void on_btnThem_clicked();
    void on_btnXoa_clicked();
    void on_btnThongKe_clicked();
    void on_btnSapXep_clicked();
    void HienThiCSVLenTableWidget(const QString& filePath);
};

#endif // MAINWINDOW_H
