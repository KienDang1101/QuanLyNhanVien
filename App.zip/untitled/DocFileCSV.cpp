#include "DocFileCSV.h"
#include <QFile>
#include <QTextStream>
#include <QStringList>
#include <QDebug>

QVector<NhanVien*> DanhSachNhanVien;

void DocFileCSV::DocFile(const QString& filePath)
{
    for (NhanVien* nv : DanhSachNhanVien)
        delete nv;
    DanhSachNhanVien.clear();

    QFile file(filePath);
    if (!file.open(QIODevice::ReadOnly | QIODevice::Text)) {
        qDebug() << "Không thể mở file:" << filePath;
        return;
    }

    QTextStream in(&file);
    QString header = in.readLine(); // bỏ qua dòng tiêu đề

    while (!in.atEnd()) {
        QString line = in.readLine();
        QStringList fields = line.split(',');

        if (fields.size() < 8)
            continue;

        int id = fields[0].toInt();
        QString hoten = fields[1];
        QString chucvu = fields[2];
        QString ngaylam = fields[3];
        int ngaylamviec = fields[4].toInt();
        int ngayphep = fields[5].toInt();
        int nghikp = fields[6].toInt();
        int luongcb = fields[7].toInt();

        NhanVien* nv = nullptr;
        if (chucvu == "Nhan vien") nv = new NhanVienVanPhong();
        else if (chucvu == "Pho phong") nv = new PhoPhong();
        else if (chucvu == "Truong phong") nv = new TruongPhong();

        if (nv) {
            nv->setID(id);
            nv->setHoTen(hoten);
            nv->setChucVu(chucvu);
            nv->setNgayLam(ngaylam);
            nv->setNgayLamViec(ngaylamviec);
            nv->setNgayPhepTichLuy(ngayphep);
            nv->setNgayNghiKhongPhep(nghikp);

            if (auto* vp = dynamic_cast<NhanVienVanPhong*>(nv))
                vp->setLuongCoBan(luongcb);
            else if (auto* pp = dynamic_cast<PhoPhong*>(nv))
                pp->setLuongCoBan(luongcb);
            else if (auto* tp = dynamic_cast<TruongPhong*>(nv))
                tp->setLuongCoBan(luongcb);

            DanhSachNhanVien.append(nv);
        }
    }

    qDebug() << "Đọc file thành công!";
    file.close();
}
