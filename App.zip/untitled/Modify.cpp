#include "Modify.h"
#include <QTextStream>
#include <QVector>
#include <QString>
#include <QDebug>

void Modify::Them(int id, int ngaylamviec, int ngayphep, int nghikp, int luongcb, QString hoten, QString ngaylam, QString chucvu) {
    NhanVien* nv = nullptr;
    if (chucvu == "Nhan vien") nv = new NhanVienVanPhong();
    else if (chucvu == "Pho phong") nv = new PhoPhong();
    else if (chucvu == "Truong phong") nv = new TruongPhong();

    nv->setID(id);
    nv->setHoTen(hoten);
    nv->setChucVu(chucvu);
    nv->setNgayLam(ngaylam);
    nv->setNgayLamViec(ngaylamviec);
    nv->setNgayPhepTichLuy(ngayphep);
    nv->setNgayNghiKhongPhep(nghikp);

    if (NhanVienVanPhong* vp = dynamic_cast<NhanVienVanPhong*>(nv))
        vp->setLuongCoBan(luongcb);
    else if (PhoPhong* pp = dynamic_cast<PhoPhong*>(nv))
        pp->setLuongCoBan(luongcb);
    else if (TruongPhong* tp = dynamic_cast<TruongPhong*>(nv))
        tp->setLuongCoBan(luongcb);

    DanhSachNhanVien.append(nv);
}

void Modify::Xoa(int id) {
    QString keyword = QString::number(id);

    bool isNumber = true;
    for (const QChar& c : keyword) {
        if (!c.isDigit()) {
            isNumber = false;
            break;
        }
    }

    auto it = DanhSachNhanVien.begin();
    while (it != DanhSachNhanVien.end()) {
        NhanVien* nv = *it;
        if ((isNumber && nv->getID() == keyword.toInt()) || (!isNumber && (nv->getHoTen()) == keyword)) {
            delete nv;
            it = DanhSachNhanVien.erase(it);
        } else {
            ++it;
        }
    }
}

void Modify::ChinhSua(int id, int ngaylamviec, int ngayphep, int nghikp, int luongcb, QString hoten, QString ngaylam, QString chucvu) {
    QString keyword =  QString::number(id);;

    for (int i = 0; i < DanhSachNhanVien.size(); ++i) {
        NhanVien* nv = DanhSachNhanVien[i];
        if (QString::number(nv->getID()) == keyword || (nv->getHoTen()) == keyword) {
            if (chucvu == "Nhan vien") nv = new NhanVienVanPhong();
            else if (chucvu == "Pho phong") nv = new PhoPhong();
            else if (chucvu == "Truong phong") nv = new TruongPhong();

            nv->setID(id);
            nv->setHoTen(hoten);
            nv->setChucVu(chucvu);
            nv->setNgayLam(ngaylam);
            nv->setNgayLamViec(ngaylamviec);
            nv->setNgayPhepTichLuy(ngayphep);
            nv->setNgayNghiKhongPhep(nghikp);

            if (NhanVienVanPhong* vp = dynamic_cast<NhanVienVanPhong*>(nv))
                vp->setLuongCoBan(luongcb);
            else if (PhoPhong* pp = dynamic_cast<PhoPhong*>(nv))
                pp->setLuongCoBan(luongcb);
            else if (TruongPhong* tp = dynamic_cast<TruongPhong*>(nv))
                tp->setLuongCoBan(luongcb);

            DanhSachNhanVien[i] = nv;
        }
    }
    return;
}
