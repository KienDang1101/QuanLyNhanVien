#include "ThongKe.h"

QVector<NhanVien*> ThongKe::List_DanhGia(const QVector<NhanVien*>& danhSach, const QString& bacDanhGia) {
    QVector<NhanVien*> thongKeNV;
    for (NhanVien* nv : danhSach) {
        if ((nv->DanhGia()) == bacDanhGia) {
            thongKeNV.append(nv);
        }
    }
    return thongKeNV;
}

QVector<NhanVien*> ThongKe::List_NgayNghi(const QVector<NhanVien*>& danhSach, int max) {
    QVector<NhanVien*> thongKeNV;
    for (NhanVien* nv : danhSach) {
        if (nv->getNgayNghiKhongPhep() <= max) {
            thongKeNV.append(nv);
        }
    }
    return thongKeNV;
}
