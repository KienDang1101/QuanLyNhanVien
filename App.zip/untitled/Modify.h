#ifndef MODIFY_H
#define MODIFY_H

#include "NhanVien.h"
#include <QVector>

extern QVector<NhanVien*> DanhSachNhanVien;

class Modify {
public:
    static void Them(int, int, int, int, int, QString, QString, QString);
    static void Xoa(int);
    static void ChinhSua(int, int, int, int, int, QString, QString, QString);
};

#endif
