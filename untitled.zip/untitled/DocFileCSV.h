#ifndef DOCFILECSV_H
#define DOCFILECSV_H

#include "NhanVien.h"
#include <QVector>

extern QVector<NhanVien*> DanhSachNhanVien;

class DocFileCSV
{
public:
    static void DocFile(const QString& filePath);
};

#endif
