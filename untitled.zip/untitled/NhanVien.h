#ifndef NHANVIEN_H
#define NHANVIEN_H

#include <QString>

class NhanVien
{
protected:
    int ID;
    QString HoTen;
    QString NgayLam;
    QString ChucVu;
    int NgayLamViec;
    int NgayPhepTichLuy;
    int NgayNghiKhongPhep;

public:
    NhanVien();
    NhanVien(int, QString, QString, QString, int, int, int);
    virtual ~NhanVien();

    void setID(int);
    int getID() const;

    void setHoTen(QString);
    QString getHoTen() const;

    void setNgayLam(QString);
    QString getNgayLam() const;

    void setChucVu(QString);
    QString getChucVu() const;

    void setNgayLamViec(int);
    int getNgayLamViec() const;

    void setNgayPhepTichLuy(int);
    int getNgayPhepTichLuy() const;

    void setNgayNghiKhongPhep(int);
    int getNgayNghiKhongPhep() const;

    virtual int getLuongCoBan() const;

    QString DanhGia();
    float HeSoLuong();
    virtual float TinhLuong();
};

// ==== TruongPhong ====
class TruongPhong : public NhanVien
{
private:
    int LuongCoBan;
public:
    TruongPhong();
    TruongPhong(int, QString, QString, QString, int, int, int, int);
    ~TruongPhong();

    void setLuongCoBan(int);
    int getLuongCoBan() const;
    float TinhLuong();
};

// ==== PhoPhong ====
class PhoPhong : public NhanVien
{
private:
    int LuongCoBan;
public:
    PhoPhong();
    PhoPhong(int, QString, QString, QString, int, int, int, int);
    ~PhoPhong();

    void setLuongCoBan(int);
    int getLuongCoBan() const;
    float TinhLuong();
};

// ==== NhanVienVanPhong ====
class NhanVienVanPhong : public NhanVien
{
private:
    int LuongCoBan;
public:
    NhanVienVanPhong();
    NhanVienVanPhong(int, QString, QString, QString, int, int, int, int);
    ~NhanVienVanPhong();

    void setLuongCoBan(int);
    int getLuongCoBan() const;
    float TinhLuong();
};

#endif // NHANVIEN_H
