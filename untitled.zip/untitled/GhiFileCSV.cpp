#include "GhiFileCSV.h"
#include <QFile>
#include <QTextStream>
#include <QDebug>

void GhiFileCSV::GhiFile(const QString& filePath)
{
    QFile file(filePath);
    if (!file.open(QIODevice::WriteOnly | QIODevice::Text)) {
        qDebug() << "Không thể tạo file:" << filePath;
        return;
    }

    QTextStream out(&file);

    out << "ID,Ten,Chuc vu,Ngay bat dau lam,Ngay lam viec,Ngay nghi phep tich luy,Ngay nghi khong phep,Luong co ban,He so luong,Luong thuc te,Danh gia\n";

    for (NhanVien* nv : DanhSachNhanVien) {
        out << (nv->getID()) << ","
            << (nv->getHoTen()) << ","
            << (nv->getChucVu()) << ","
            << (nv->getNgayLam()) << ","
            << (nv->getNgayLamViec()) << ","
            << (nv->getNgayPhepTichLuy()) << ","
            << (nv->getNgayNghiKhongPhep()) << ","
            << (nv->getLuongCoBan()) << ","
            << (nv->HeSoLuong()) << ","
            << (nv->TinhLuong()) << ","
            << (nv->DanhGia()) << "\n";
    }

    file.close();
    qDebug() << "Ghi file thành công!";
}
