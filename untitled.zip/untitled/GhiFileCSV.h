#ifndef GHIFILECSV_H
#define GHIFILECSV_H

#include "NhanVien.h"
#include <QVector>
#include <QString>

extern QVector<NhanVien*> DanhSachNhanVien;

class GhiFileCSV
{
public:
    static void GhiFile(const QString& filePath);
};

#endif
