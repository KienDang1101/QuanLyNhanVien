#ifndef SAPXEP_H
#define SAPXEP_H

#include "NhanVien.h"
#include <QVector>
#include <QString>

class SAPXEP
{
public:
    static int convertDanhGia(const QString& danhGia);

    // choose: 1-6 tương ứng ID, NgayLamViec, NgayPhep, NgayKhongPhep, Luong, DanhGia
    // tanggiam: 1 tăng dần, 2 giảm dần
    static void SapXepDSNV(QVector<NhanVien*>& danhSachNhanVien, int choose, int tanggiam);
};

#endif
